Para executar a aplicação, é necessário ter o tkinter instalado. Caso não tenha, executar o seguinte comando: 
sudo apt-get install python3-pil python3-pil.imagetk

Para executar o programa, com a versão 3 do python, usar o comando:
python3 PlayerInterface.py
